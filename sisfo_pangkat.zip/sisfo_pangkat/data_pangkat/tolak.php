<?php

$id_pangkat = $_GET['id_pangkat'];

$tolak = mysqli_query($koneksi, "UPDATE tb_pangkat SET status_berkas='ditolak'
WHERE id_pangkat='$id_pangkat'");

if ($tolak) {
    echo "<script>
    alert('Data Berhasil Ditolak')
    window.location.href='?page=data_pangkat/index'
    </script>";
}
