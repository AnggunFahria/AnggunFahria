<?php

$id_pangkat = $_GET['id_pangkat'];

$konfirmasi = mysqli_query($koneksi, "UPDATE tb_pangkat SET status_berkas='konfirmasi'
WHERE id_pangkat='$id_pangkat'");

if ($konfirmasi) {
    echo "<script>
    alert('Data Berhasil Dikonfirmasi')
    window.location.href='?page=data_pangkat/index'
    </script>";
}
