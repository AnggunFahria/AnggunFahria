<?php
$old = (object) @$_GET['old'];
$errors = (object) @$_GET['errors'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Formulir Kenaikan Pangkat</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f4f4f4;
        }

        .container {
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 8px;
        }

        input {
            padding: 8px;
            margin-bottom: 16px;
        }

        button {
            padding: 10px;
            background-color: #4caf50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <div class="container mt-3 mb-3">
        <h2>Formulir Kenaikan Pangkat</h2>
        <br>
        <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="nama">Nama: <span style="color:red;">*</span></label>
                        <input type="text" name="nama" value="<?php echo @$old->nama ?>">
                        <?php
                        if (@$errors->nama) : ?>
                            <div style="color: red"><?php echo $errors->nama[0] ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="nip">NIP: <span style="color:red;">*</span></label>
                        <input type="text" name="nip" value="<?php echo @$old->nip ?>">
                        <?php
                        if (@$errors->nip) : ?>
                            <div style="color: red"><?php echo $errors->nip[0] ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="pangkat">Pangkat Saat Ini: <span style="color:red;">*</span></label>
                        <select name="pangkat_sekarang" id="" class="form-control">
                            <option value="">Pilih Pangkat Saat Ini</option>
                            <option value="1a" <?= @$old->pangkat_sekarang == '1a' ? 'selected' : '' ?>>1A</option>
                            <option value="1b" <?= @$old->pangkat_sekarang == '1b' ? 'selected' : '' ?>>1B</option>
                            <option value="1c" <?= @$old->pangkat_sekarang == '1c' ? 'selected' : '' ?>>1C</option>
                            <option value="1d" <?= @$old->pangkat_sekarang == '1d' ? 'selected' : '' ?>>1D</option>
                            <option value="2a" <?= @$old->pangkat_sekarang == '2a' ? 'selected' : '' ?>>2A</option>
                            <option value="2b" <?= @$old->pangkat_sekarang == '2b' ? 'selected' : '' ?>>2B</option>
                            <option value="2c" <?= @$old->pangkat_sekarang == '2c' ? 'selected' : '' ?>>2C</option>
                            <option value="2d" <?= @$old->pangkat_sekarang == '2d' ? 'selected' : '' ?>>2D</option>
                            <option value="3a" <?= @$old->pangkat_sekarang == '3a' ? 'selected' : '' ?>>3A</option>
                            <option value="3b" <?= @$old->pangkat_sekarang == '3b' ? 'selected' : '' ?>>3B</option>
                            <option value="3c" <?= @$old->pangkat_sekarang == '3c' ? 'selected' : '' ?>>3C</option>
                            <option value="3d" <?= @$old->pangkat_sekarang == '3d' ? 'selected' : '' ?>>3D</option>
                            <option value="4a" <?= @$old->pangkat_sekarang == '4a' ? 'selected' : '' ?>>4A</option>
                            <option value="4b" <?= @$old->pangkat_sekarang == '4b' ? 'selected' : '' ?>>4B</option>
                            <option value="4c" <?= @$old->pangkat_sekarang == '4c' ? 'selected' : '' ?>>4C</option>
                        </select>
                        <?php
                        if (@$errors->pangkat_sekarang) : ?>
                            <div style="color: red"><?php echo $errors->pangkat_sekarang[0] ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="kenaikan">Kenaikan Pangkat: <span style="color:red;">*</span></label>
                        <select name="kenaikan_pangkat" id="" class="form-control">
                            <option value="">Pilih Kenaikan Pangkat</option>
                            <option value="1a" <?= @$old->kenaikan_pagkat == '1a' ? 'selected' : '' ?>>1A</option>
                            <option value="1b" <?= @$old->kenaikan_pagkat == '1b' ? 'selected' : '' ?>>1B</option>
                            <option value="1c" <?= @$old->kenaikan_pagkat == '1c' ? 'selected' : '' ?>>1C</option>
                            <option value="1d" <?= @$old->kenaikan_pagkat == '1d' ? 'selected' : '' ?>>1D</option>
                            <option value="2a" <?= @$old->kenaikan_pagkat == '2a' ? 'selected' : '' ?>>2A</option>
                            <option value="2b" <?= @$old->kenaikan_pagkat == '2b' ? 'selected' : '' ?>>2B</option>
                            <option value="2c" <?= @$old->kenaikan_pagkat == '2c' ? 'selected' : '' ?>>2C</option>
                            <option value="2d" <?= @$old->kenaikan_pagkat == '2d' ? 'selected' : '' ?>>2D</option>
                            <option value="3a" <?= @$old->kenaikan_pagkat == '3a' ? 'selected' : '' ?>>3A</option>
                            <option value="3b" <?= @$old->kenaikan_pagkat == '3b' ? 'selected' : '' ?>>3B</option>
                            <option value="3c" <?= @$old->kenaikan_pagkat == '3c' ? 'selected' : '' ?>>3C</option>
                            <option value="3d" <?= @$old->kenaikan_pagkat == '3d' ? 'selected' : '' ?>>3D</option>
                            <option value="4a" <?= @$old->kenaikan_pagkat == '4a' ? 'selected' : '' ?>>4A</option>
                            <option value="4b" <?= @$old->kenaikan_pagkat == '4b' ? 'selected' : '' ?>>4B</option>
                            <option value="4c" <?= @$old->kenaikan_pagkat == '4c' ? 'selected' : '' ?>>4C</option>
                        </select>
                        <?php
                        if (@$errors->kenaikan_pangkat) : ?>
                            <div style="color: red"><?php echo $errors->kenaikan_pangkat[0] ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="sk80">SK 80: <span style="color:red;">*</span></label>
                        <input type="file" class="form-control" name="sk80" value="<?php echo @$old->sk80 ?>" required>
                        <?php
                        if (@$errors->sk80) : ?>
                            <div style="color: red"><?php echo $errors->sk80[0] ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="sk100">SK 100: <span style="color:red;">*</span></label>
                        <input type="file" class="form-control" name="sk100" value="<?php echo @$old->sk100 ?>" required>
                        <?php
                        if (@$errors->sk100) : ?>
                            <div style="color: red"><?php echo $errors->sk100[0] ?></div>
                        <?php endif; ?>
                    </div>


                </div>

                <div class="col-md-6">

                    <div class="form-group">
                        <label for="skPangkatTerakhir">SK Pangkat Terakhir: <span style="color:red;">*</span></label>
                        <input type="file" class="form-control" name="sk_terakhir" value="<?php echo @$old->sk_terakhir ?>" required>
                        <?php
                        if (@$errors->sk_terakhir) : ?>
                            <div style="color: red"><?php echo $errors->sk_terakhir[0] ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="skMutasi">SK Mutasi (*Jika Ada):</label>
                        <input type="file" class="form-control" name="sk_mutasi" value="<?php echo @$old->sk_mutasi ?>">
                        <?php
                        if (@$errors->sk_mutasi) : ?>
                            <div style="color: red"><?php echo $errors->sk_mutasi[0] ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="skp2022">SKP Tahun 2022: <span style="color:red;">*</span></label>
                        <input type="file" class="form-control" name="skp2022" value="<?php echo @$old->skp2022 ?>" required>
                        <?php
                        if (@$errors->skp2022) : ?>
                            <div style="color: red"><?php echo $errors->skp2022[0] ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="skp2023">SKP Tahun 2023: <span style="color:red;">*</span></label>
                        <input type="file" class="form-control" name="skp2023" value="<?php echo @$old->skp2023 ?>" required>
                        <?php
                        if (@$errors->skp2023) : ?>
                            <div style="color: red"><?php echo $errors->skp2023[0] ?></div>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="btn btn-success mt-3">Kirim</button>
                </div>

                <!-- <button type="button" onclick="ajukanKenaikan()" class="btn btn-success">Input Persyaratan</button> -->
            </div>
        </form>

    </div>

    <script src="script.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <script>
        function ajukanKenaikan() {
            // Mengambil data dari formulir
            var nama = document.getElementById('nama').value;
            var pangkat = document.getElementById('pangkat').value;
            var kenaikan = parseInt(document.getElementById('kenaikan').value);

            // Validasi data
            if (nama && pangkat && kenaikan > 0) {
                // Mengirim data ke backend (simulasi)
                alert(`Pengajuan kenaikan pangkat untuk ${nama} (${pangkat}) KE ${kenaikan} berhasil diajukan.`);
            } else {
                alert('Harap lengkapi formulir dengan benar.');
            }

        }
    </script>
</body>


</html>