<?php

$listPesanError = [
    'required' => function ($field) {
        return "Field {$field} harus diisi.";
    },
    'nip' => function ($field) {
        return "Field {$field} harus berupa email yang valid.";
    },
    'pangkat_sekarang' => function ($field) {
        return "Field {$field} harus berupa angka numerik.";
    },
    'kenaikan_pangkat' => function ($field) {
        return "Field {$field} harus berupa url yang valid.";
    },
    'sk80' => function ($field) {
        return "Field {$field} hanya boleh berisi huruf, angka, dan underscore.";
    },
    'sk100' => function ($field) {
        return "Field {$field} hanya boleh berisi huruf, angka, dan underscore.";
    },
    'sk_terakhir' => function ($field) {
        return "Field {$field} hanya boleh berisi huruf, angka, dan underscore.";
    },
    'sk_pelantikan' => function ($field) {
        return "Field {$field} hanya boleh berisi huruf, angka, dan underscore.";
    },
];
