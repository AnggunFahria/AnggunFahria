<?php

$id = $_GET['id_pangkat'];

$hapus = mysqli_query($koneksi, "DELETE FROM tb_pangkat WHERE id_pangkat='$id'");

if ($hapus) {
    echo "<script>
    alert('Data Berhasil Dihapus')
    window.location.href='?page=pangkat/struktural'
    </script>";
} else {
    echo "<script>
    alert('Data Gagal Dihapus')
    window.location.href='?page=pangkat/struktural'
    </script>";
}
