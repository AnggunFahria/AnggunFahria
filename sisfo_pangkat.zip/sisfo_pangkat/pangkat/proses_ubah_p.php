<?php
include "../koneksi.php";

$id_pangkat = $_POST['id_pangkat'];
$nama = $_POST['nama'];
$nip = $_POST['nip'];
$pangkat_sekarang = $_POST['pangkat_sekarang'];
$kenaikan_pangkat = $_POST['kenaikan_pangkat'];


if ($_FILES['sk80']['name'] == '') {
    //jika foto kosong
    $namafile = $_POST['sk80_old'];
} else {
    // ambil data file
    $namafile = $_FILES['sk80']['name'];
    $namaSementara = $_FILES['sk80']['tmp_name'];
    // pindahkan file
    $terupload = move_uploaded_file($namaSementara, '../uploads/' . $namafile);
}

if ($_FILES['sk100']['name'] == '') {
    //jika foto kosong
    $namafile2 = $_POST['sk100_old'];
} else {
    // ambil data file
    $namafile2 = $_FILES['sk100']['name'];
    $namaSementara2 = $_FILES['sk100']['tmp_name'];
    // pindahkan file
    $terupload = move_uploaded_file($namaSementara2, '../uploads/' . $namafile2);
}

if ($_FILES['sk_terakhir']['name'] == '') {
    //jika foto kosong
    $namafile3 = $_POST['sk_terakhir_old'];
} else {
    // ambil data file
    $namafile3 = $_FILES['sk_terakhir']['name'];
    $namaSementara3 = $_FILES['sk_terakhir']['tmp_name'];
    // pindahkan file
    $terupload = move_uploaded_file($namaSementara3, '../uploads/' . $namafile3);
}

if ($_FILES['sk_mutasi']['name'] == '') {
    //jika foto kosong
    $namafile4 = $_POST['sk_mutasi_old'];
} else {
    // ambil data file
    $namafile4 = $_FILES['sk_mutasi']['name'];
    $namaSementara4 = $_FILES['sk_mutasi']['tmp_name'];
    // pindahkan file
    $terupload = move_uploaded_file($namaSementara4, '../uploads/' . $namafile4);
}

$ubah = mysqli_query($koneksi, "UPDATE tb_pangkat SET nama='$nama', nip='$nip', pangkat_sekarang='$pangkat_sekarang', kenaikan_pangkat='$kenaikan_pangkat', sk80='$namafile', sk100='$namafile2', sk_terakhir='$namafile3', sk_mutasi='$namafile4'
WHERE id_pangkat='$id_pangkat'");

if ($ubah) {
    echo "<script>
    alert('Data Berhasil Diubah')
    window.location.href='../?page=pangkat/pelaksana'
    </script>";
} else {
    echo "<script>
    alert('Data Gagal Diubah')
    window.location.href='../?page=pangkat/ubah'
    </script>";
}
