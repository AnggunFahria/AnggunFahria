                <!-- Container Fluid-->
                <div class="container-fluid" id="container-wrapper">
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Data Pangkat Fungsional</h1>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="./">Home</a></li>
                            <li class="breadcrumb-item">Pangkat</li>
                            <li class="breadcrumb-item active" aria-current="page">Data Pangkat Fungsional</li>
                        </ol>
                    </div>

                    <!-- Row -->
                    <div class="row">
                        <!-- Datatables -->
                        <div class="col-lg-12">
                            <div class="card mb-4">
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">
                                        <!-- Button trigger modal -->
                                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                                            <i class="fa fa-plus"> Tambah Data </i>
                                        </button>
                                    </h6>
                                </div>
                                <div class="table-responsive p-3">
                                    <table class="table align-items-center table-flush table-hover" id="dataTable">
                                        <thead class="thead-light">
                                            <tr>
                                                <th>No</th>
                                                <th>Nama</th>
                                                <th>NIP</th>
                                                <th>Pangkat Sekarang</th>
                                                <th>Kenaikan Pangkat</th>
                                                <th>SK 80</th>
                                                <th>SK 100</th>
                                                <th>SK Terakhir</th>
                                                <th>SK Mutasi</th>
                                                <th>Penilaian Angka Kredit</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            $query = mysqli_query($koneksi, "SELECT * FROM tb_pangkat WHERE jenis='fungsional' ORDER BY id_pangkat DESC");
                                            while ($data = mysqli_fetch_array($query)) {
                                            ?>
                                                <tr>
                                                    <td><?= $no++ ?></td>
                                                    <td><?= $data['nama'] ?></td>
                                                    <td><?= $data['nip'] ?></td>
                                                    <td><?= $data['pangkat_sekarang'] ?></td>
                                                    <td><?= $data['kenaikan_pangkat'] ?></td>
                                                    <td><a href="uploads/<?= $data['sk80'] ?>">SK 80</a></td>
                                                    <td><a href="uploads/<?= $data['sk100'] ?>">SK 100</a></td>
                                                    <td><a href="uploads/<?= $data['sk_terakhir'] ?>">SK Terakhir</a></td>
                                                    <td><a href="uploads/<?= $data['sk_mutasi'] ?>">SK Mutasi</a></td>
                                                    <td><a href="uploads/<?= $data['pak'] ?>">PAK</a></td>
                                                    <td>
                                                        <button type="button" class="btn btn-success btn-block" data-toggle="modal" data-target="#edit<?= $data['id_pangkat'] ?>">
                                                            <i class="fa fa-edit"></i>
                                                        </button>
                                                        <a href="?page=pangkat/hapus&id_pangkat=<?= $data['id_pangkat'] ?>" class="btn btn-danger btn-block"><i class="fa fa-trash"></i></a>
                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Row-->

                    <!-- Modal Tambah -->
                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                                <form action="pangkat/proses_tambah.php" method="post" enctype="multipart/form-data">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Form Tambah Kenaikan Pangkat Fungsional</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="nama">Nama: <span style="color:red;">*</span></label>
                                                    <input type="text" name="nama" value="<?php echo @$old->nama ?>" class="form-control">
                                                    <?php
                                                    if (@$errors->nama) : ?>
                                                        <div style="color: red"><?php echo $errors->nama[0] ?></div>
                                                    <?php endif; ?>
                                                </div>

                                                <div class="form-group">
                                                    <label for="nip">NIP: <span style="color:red;">*</span></label>
                                                    <input type="text" name="nip" value="<?php echo @$old->nip ?>" class="form-control">
                                                    <?php
                                                    if (@$errors->nip) : ?>
                                                        <div style="color: red"><?php echo $errors->nip[0] ?></div>
                                                    <?php endif; ?>
                                                </div>

                                                <div class="form-group">
                                                    <label for="pangkat">Pangkat Saat Ini: <span style="color:red;">*</span></label>
                                                    <select name="pangkat_sekarang" id="" class="form-control">
                                                        <option value="">Pilih Pangkat Saat Ini</option>
                                                        <option value="1a" <?= @$old->pangkat_sekarang == '1a' ? 'selected' : '' ?>>1A</option>
                                                        <option value="1b" <?= @$old->pangkat_sekarang == '1b' ? 'selected' : '' ?>>1B</option>
                                                        <option value="1c" <?= @$old->pangkat_sekarang == '1c' ? 'selected' : '' ?>>1C</option>
                                                        <option value="1d" <?= @$old->pangkat_sekarang == '1d' ? 'selected' : '' ?>>1D</option>
                                                        <option value="2a" <?= @$old->pangkat_sekarang == '2a' ? 'selected' : '' ?>>2A</option>
                                                        <option value="2b" <?= @$old->pangkat_sekarang == '2b' ? 'selected' : '' ?>>2B</option>
                                                        <option value="2c" <?= @$old->pangkat_sekarang == '2c' ? 'selected' : '' ?>>2C</option>
                                                        <option value="2d" <?= @$old->pangkat_sekarang == '2d' ? 'selected' : '' ?>>2D</option>
                                                        <option value="3a" <?= @$old->pangkat_sekarang == '3a' ? 'selected' : '' ?>>3A</option>
                                                        <option value="3b" <?= @$old->pangkat_sekarang == '3b' ? 'selected' : '' ?>>3B</option>
                                                        <option value="3c" <?= @$old->pangkat_sekarang == '3c' ? 'selected' : '' ?>>3C</option>
                                                        <option value="3d" <?= @$old->pangkat_sekarang == '3d' ? 'selected' : '' ?>>3D</option>
                                                        <option value="4a" <?= @$old->pangkat_sekarang == '4a' ? 'selected' : '' ?>>4A</option>
                                                        <option value="4b" <?= @$old->pangkat_sekarang == '4b' ? 'selected' : '' ?>>4B</option>
                                                        <option value="4c" <?= @$old->pangkat_sekarang == '4c' ? 'selected' : '' ?>>4C</option>
                                                    </select>
                                                    <?php
                                                    if (@$errors->pangkat_sekarang) : ?>
                                                        <div style="color: red"><?php echo $errors->pangkat_sekarang[0] ?></div>
                                                    <?php endif; ?>
                                                </div>

                                                <div class="form-group">
                                                    <label for="kenaikan">Kenaikan Pangkat: <span style="color:red;">*</span></label>
                                                    <select name="kenaikan_pangkat" id="" class="form-control">
                                                        <option value="">Pilih Kenaikan Pangkat</option>
                                                        <option value="1a" <?= @$old->kenaikan_pagkat == '1a' ? 'selected' : '' ?>>1A</option>
                                                        <option value="1b" <?= @$old->kenaikan_pagkat == '1b' ? 'selected' : '' ?>>1B</option>
                                                        <option value="1c" <?= @$old->kenaikan_pagkat == '1c' ? 'selected' : '' ?>>1C</option>
                                                        <option value="1d" <?= @$old->kenaikan_pagkat == '1d' ? 'selected' : '' ?>>1D</option>
                                                        <option value="2a" <?= @$old->kenaikan_pagkat == '2a' ? 'selected' : '' ?>>2A</option>
                                                        <option value="2b" <?= @$old->kenaikan_pagkat == '2b' ? 'selected' : '' ?>>2B</option>
                                                        <option value="2c" <?= @$old->kenaikan_pagkat == '2c' ? 'selected' : '' ?>>2C</option>
                                                        <option value="2d" <?= @$old->kenaikan_pagkat == '2d' ? 'selected' : '' ?>>2D</option>
                                                        <option value="3a" <?= @$old->kenaikan_pagkat == '3a' ? 'selected' : '' ?>>3A</option>
                                                        <option value="3b" <?= @$old->kenaikan_pagkat == '3b' ? 'selected' : '' ?>>3B</option>
                                                        <option value="3c" <?= @$old->kenaikan_pagkat == '3c' ? 'selected' : '' ?>>3C</option>
                                                        <option value="3d" <?= @$old->kenaikan_pagkat == '3d' ? 'selected' : '' ?>>3D</option>
                                                        <option value="4a" <?= @$old->kenaikan_pagkat == '4a' ? 'selected' : '' ?>>4A</option>
                                                        <option value="4b" <?= @$old->kenaikan_pagkat == '4b' ? 'selected' : '' ?>>4B</option>
                                                        <option value="4c" <?= @$old->kenaikan_pagkat == '4c' ? 'selected' : '' ?>>4C</option>
                                                    </select>
                                                    <?php
                                                    if (@$errors->kenaikan_pangkat) : ?>
                                                        <div style="color: red"><?php echo $errors->kenaikan_pangkat[0] ?></div>
                                                    <?php endif; ?>
                                                </div>

                                            </div>

                                            <div class="col-md-6">

                                                <div class="form-group">
                                                    <label for="sk80">SK 80: <span style="color:red;">*</span></label>
                                                    <input type="file" class="form-control" name="sk80" value="<?php echo @$old->sk80 ?>" required>
                                                    <?php
                                                    if (@$errors->sk80) : ?>
                                                        <div style="color: red"><?php echo $errors->sk80[0] ?></div>
                                                    <?php endif; ?>
                                                </div>

                                                <div class="form-group">
                                                    <label for="sk100">SK 100: <span style="color:red;">*</span></label>
                                                    <input type="file" class="form-control" name="sk100" value="<?php echo @$old->sk100 ?>" required>
                                                    <?php
                                                    if (@$errors->sk100) : ?>
                                                        <div style="color: red"><?php echo $errors->sk100[0] ?></div>
                                                    <?php endif; ?>
                                                </div>

                                                <div class="form-group">
                                                    <label for="skPangkatTerakhir">SK Pangkat Terakhir: <span style="color:red;">*</span></label>
                                                    <input type="file" class="form-control" name="sk_terakhir" value="<?php echo @$old->sk_terakhir ?>" required>
                                                    <?php
                                                    if (@$errors->sk_terakhir) : ?>
                                                        <div style="color: red"><?php echo $errors->sk_terakhir[0] ?></div>
                                                    <?php endif; ?>
                                                </div>

                                                <div class="form-group">
                                                    <label for="skMutasi">SK Mutasi (*Jika Ada):</label>
                                                    <input type="file" class="form-control" name="sk_mutasi" value="<?php echo @$old->sk_mutasi ?>">
                                                    <?php
                                                    if (@$errors->sk_mutasi) : ?>
                                                        <div style="color: red"><?php echo $errors->sk_mutasi[0] ?></div>
                                                    <?php endif; ?>
                                                </div>

                                                <div class="form-group">
                                                    <label>Penilaian Angka Kredit: <span style="color:red;">*</span></label>
                                                    <input type="file" class="form-control" name="pak" value="<?php echo @$old->pak ?>" required>
                                                    <?php
                                                    if (@$errors->pak) : ?>
                                                        <div style="color: red"><?php echo $errors->pak[0] ?></div>
                                                    <?php endif; ?>
                                                </div>

                                            </div>

                                            <!-- <button type="button" onclick="ajukanKenaikan()" class="btn btn-success">Input Persyaratan</button> -->
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Save changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Modal Ubah -->
                    <?php
                    $no = 1;
                    $query2 = mysqli_query($koneksi, "SELECT * FROM tb_pangkat ORDER BY id_pangkat DESC");
                    while ($pangkat = mysqli_fetch_array($query2)) {
                    ?>
                        <div class="modal fade" id="edit<?= $pangkat['id_pangkat'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-lg" role="document">
                                <div class="modal-content">
                                    <form action="pangkat/proses_ubah.php" method="post" enctype="multipart/form-data">
                                        <input type="hidden" name="id_pangkat" value="<?= $pangkat['id_pangkat'] ?>">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Form Ubah Kenaikan Pangkat Fungsional</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="nama">Nama: <span style="color:red;">*</span></label>
                                                        <input type="text" name="nama" value="<?= $pangkat['nama']  ?>" class="form-control">
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="nip">NIP: <span style="color:red;">*</span></label>
                                                        <input type="text" name="nip" value="<?= $pangkat['nip']  ?>" class="form-control">
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="pangkat">Pangkat Saat Ini: <span style="color:red;">*</span></label>
                                                        <select name="pangkat_sekarang" id="" class="form-control">
                                                            <option value="">Pilih Pangkat Saat Ini</option>
                                                            <option value="1a" <?= $pangkat['pangkat_sekarang'] == '1a' ? 'selected' : '' ?>>1A</option>
                                                            <option value="1b" <?= $pangkat['pangkat_sekarang'] == '1b' ? 'selected' : '' ?>>1B</option>
                                                            <option value="1c" <?= $pangkat['pangkat_sekarang'] == '1c' ? 'selected' : '' ?>>1C</option>
                                                            <option value="1d" <?= $pangkat['pangkat_sekarang'] == '1d' ? 'selected' : '' ?>>1D</option>
                                                            <option value="2a" <?= $pangkat['pangkat_sekarang'] == '2a' ? 'selected' : '' ?>>2A</option>
                                                            <option value="2b" <?= $pangkat['pangkat_sekarang'] == '2b' ? 'selected' : '' ?>>2B</option>
                                                            <option value="2c" <?= $pangkat['pangkat_sekarang'] == '2c' ? 'selected' : '' ?>>2C</option>
                                                            <option value="2d" <?= $pangkat['pangkat_sekarang'] == '2d' ? 'selected' : '' ?>>2D</option>
                                                            <option value="3a" <?= $pangkat['pangkat_sekarang'] == '3a' ? 'selected' : '' ?>>3A</option>
                                                            <option value="3b" <?= $pangkat['pangkat_sekarang'] == '3b' ? 'selected' : '' ?>>3B</option>
                                                            <option value="3c" <?= $pangkat['pangkat_sekarang'] == '3c' ? 'selected' : '' ?>>3C</option>
                                                            <option value="3d" <?= $pangkat['pangkat_sekarang'] == '3d' ? 'selected' : '' ?>>3D</option>
                                                            <option value="4a" <?= $pangkat['pangkat_sekarang'] == '4a' ? 'selected' : '' ?>>4A</option>
                                                            <option value="4b" <?= $pangkat['pangkat_sekarang'] == '4b' ? 'selected' : '' ?>>4B</option>
                                                            <option value="4c" <?= $pangkat['pangkat_sekarang'] == '4c' ? 'selected' : '' ?>>4C</option>
                                                        </select>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="kenaikan">Kenaikan Pangkat: <span style="color:red;">*</span></label>
                                                        <select name="kenaikan_pangkat" id="" class="form-control">
                                                            <option value="">Pilih Kenaikan Pangkat</option>
                                                            <option value="1a" <?= $pangkat['kenaikan_pangkat'] == '1a' ? 'selected' : '' ?>>1A</option>
                                                            <option value="1b" <?= $pangkat['kenaikan_pangkat'] == '1b' ? 'selected' : '' ?>>1B</option>
                                                            <option value="1c" <?= $pangkat['kenaikan_pangkat'] == '1c' ? 'selected' : '' ?>>1C</option>
                                                            <option value="1d" <?= $pangkat['kenaikan_pangkat'] == '1d' ? 'selected' : '' ?>>1D</option>
                                                            <option value="2a" <?= $pangkat['kenaikan_pangkat'] == '2a' ? 'selected' : '' ?>>2A</option>
                                                            <option value="2b" <?= $pangkat['kenaikan_pangkat'] == '2b' ? 'selected' : '' ?>>2B</option>
                                                            <option value="2c" <?= $pangkat['kenaikan_pangkat'] == '2c' ? 'selected' : '' ?>>2C</option>
                                                            <option value="2d" <?= $pangkat['kenaikan_pangkat'] == '2d' ? 'selected' : '' ?>>2D</option>
                                                            <option value="3a" <?= $pangkat['kenaikan_pangkat'] == '3a' ? 'selected' : '' ?>>3A</option>
                                                            <option value="3b" <?= $pangkat['kenaikan_pangkat'] == '3b' ? 'selected' : '' ?>>3B</option>
                                                            <option value="3c" <?= $pangkat['kenaikan_pangkat'] == '3c' ? 'selected' : '' ?>>3C</option>
                                                            <option value="3d" <?= $pangkat['kenaikan_pangkat'] == '3d' ? 'selected' : '' ?>>3D</option>
                                                            <option value="4a" <?= $pangkat['kenaikan_pangkat'] == '4a' ? 'selected' : '' ?>>4A</option>
                                                            <option value="4b" <?= $pangkat['kenaikan_pangkat'] == '4b' ? 'selected' : '' ?>>4B</option>
                                                            <option value="4c" <?= $pangkat['kenaikan_pangkat'] == '4c' ? 'selected' : '' ?>>4C</option>
                                                        </select>
                                                    </div>

                                                </div>

                                                <div class="col-md-6">

                                                    <div class="form-group">
                                                        <label for="sk80">SK 80: <span style="color:red;">*</span></label> (<a href="uploads/<?= $pangkat['sk80'] ?>">File Lama</a>)
                                                        <input type="hidden" class="form-control" name="sk80_old" value="<?= $pangkat['sk80'] ?>" required>
                                                        <input type="file" class="form-control" name="sk80">
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="sk100">SK 100: <span style="color:red;">*</span></label> (<a href="uploads/<?= $pangkat['sk100'] ?>">File Lama</a>)
                                                        <input type="hidden" class="form-control" name="sk100_old" value="<?= $pangkat['sk100'] ?>" required>
                                                        <input type="file" class="form-control" name="sk100">
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="skPangkatTerakhir">SK Pangkat Terakhir: <span style="color:red;">*</span></label> (<a href="uploads/<?= $pangkat['sk_terakhir'] ?>">File Lama</a>)
                                                        <input type="hidden" class="form-control" name="sk_terakhir_old" value="<?= $pangkat['sk_terakhir'] ?>" required>
                                                        <input type="file" class="form-control" name="sk_terakhir">
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="skMutasi">SK Mutasi (*Jika Ada):</label> (<a href="uploads/<?= $pangkat['sk_mutasi'] ?>">File Lama</a>)
                                                        <input type="hidden" class="form-control" name="sk_mutasi_old" value="<?= $pangkat['sk_mutasi'] ?>">
                                                        <input type="file" class="form-control" name="sk_mutasi">
                                                    </div>

                                                    <div class="form-group">
                                                        <label>Penilaian Angka Kredit: <span style="color:red;">*</span></label> (<a href="uploads/<?= $pangkat['pak'] ?>">File Lama</a>)
                                                        <input type="hidden" class="form-control" name="pak_old" value="<?= $pangkat['pak'] ?>" required>
                                                        <input type="file" class="form-control" name="pak">
                                                    </div>


                                                </div>

                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary">Save changes</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php } ?>

                    <!-- Modal Logout -->
                    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelLogout" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabelLogout">Ohh No!</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <p>Are you sure you want to logout?</p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline-success" data-dismiss="modal">Cancel</button>
                                    <a href="login/logout.php" class="btn btn-success">Logout</a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!---Container Fluid-->