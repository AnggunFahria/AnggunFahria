<?php

require_once 'fungsi-validasi-p.php';

// Proses menyimpan data persyaratan kenaikan pangkat
$nama  = $_POST['nama'];
$nip  = $_POST['nip'];
$pangkat_sekarang  = $_POST['pangkat_sekarang'];
$kenaikan_pangkat  = $_POST['kenaikan_pangkat'];


$peraturan = [
    'nama' => ['required'],
    'nip' => ['required', 'nip'],
    'pangkat_sekarang' => ['required', 'pangkat_sekarang'],
    'kenaikan_pangkat' => ['required', 'kenaikan_pangkat'],
];

$errors = validasi($peraturan);

if (count($errors) > 0) {
    $old = $_REQUEST;
    $queryString = http_build_query([
        'errors' => $errors,
        'old' => $old
    ]);

    header("Location: pelaksana.php?{$queryString}");
    die();
}

# di sini kita bisa melakukan proses yang harus dilakukan
# jika tidak terjadi error validasi apa pun.

// Lakukan validasi file dan simpan ke direktori yang sesuai
$targetDir = "../uploads/"; // Ganti dengan direktori yang sesuai
$sk80 = basename($_FILES["sk80"]["name"]);
$sk100 = basename($_FILES["sk100"]["name"]);
$sk_terakhir = basename($_FILES["sk_terakhir"]["name"]);
$sk_mutasi = basename($_FILES["sk_mutasi"]["name"]);

// Simpan file ke direktori
move_uploaded_file($_FILES["sk80"]["tmp_name"], '../uploads/' . $sk80);
move_uploaded_file($_FILES["sk100"]["tmp_name"], '../uploads/' . $sk100);
move_uploaded_file($_FILES["sk_terakhir"]["tmp_name"], '../uploads/' . $sk_terakhir);
move_uploaded_file($_FILES["sk_mutasi"]["tmp_name"], '../uploads/' . $sk_mutasi);

// Simpan informasi file ke dalam database (contoh menggunakan MySQL)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kenaikan_pangkat";

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Contoh query untuk menyimpan informasi file ke dalam tabel database
if ($sk_mutasi) {
    $sql = "INSERT INTO tb_pangkat (nama, nip, pangkat_sekarang, kenaikan_pangkat, sk80, sk100, sk_terakhir, sk_mutasi, jenis)
        VALUES ('$nama', '$nip', '$pangkat_sekarang', '$kenaikan_pangkat', '$sk80', '$sk100', '$sk_terakhir', '$sk_mutasi', 'pelaksana')";
} else {
    $sql = "INSERT INTO tb_pangkat (nama, nip, pangkat_sekarang, kenaikan_pangkat, sk80, sk100, sk_terakhir, jenis)
        VALUES ('$nama', '$nip', '$pangkat_sekarang', '$kenaikan_pangkat', '$sk80', '$sk100', '$sk_terakhir', 'pelaksana')";
}

if ($conn->query($sql) === TRUE) {
    echo "<script>
    alert('Persyaratan kenaikan pangkat berhasil disimpan')
    window.location.href='../?page=pangkat/pelaksana'
    </script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
