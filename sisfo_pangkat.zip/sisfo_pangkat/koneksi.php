<?php

$koneksi = mysqli_connect("localhost", "root", "", "kenaikan_pangkat");
